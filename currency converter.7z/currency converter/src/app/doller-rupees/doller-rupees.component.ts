import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doller-rupees',
  templateUrl: './doller-rupees.component.html',
  styleUrls: ['./doller-rupees.component.css']
})
export class DollerRupeesComponent implements OnInit {
  fromCurrencyList :any;
  convertedValue:any;
  amount :any;
  fromcurrency ="usd";

  constructor() { }

  ngOnInit(){
    this.fromCurrencyList = [{
      fromCurrency:"usd",
      toCurrency: "inr",
      value: 77
    }]; 
  
  }
  onconvert(){
    for (var currencyIndex in this.fromCurrencyList) {
      if (this.fromcurrency == this.fromCurrencyList[currencyIndex].fromCurrency) {
        this.convertedValue = (this.amount * this.fromCurrencyList[currencyIndex].value);
      }
    }
  }
}

