import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DollerRupeesComponent } from './doller-rupees.component';

describe('DollerRupeesComponent', () => {
  let component: DollerRupeesComponent;
  let fixture: ComponentFixture<DollerRupeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DollerRupeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DollerRupeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
